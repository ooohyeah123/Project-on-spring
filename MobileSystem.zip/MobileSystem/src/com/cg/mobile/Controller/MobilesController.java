package com.cg.mobile.Controller;



public class MobilesController 
{

}
