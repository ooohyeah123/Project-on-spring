Cufon.replace('#slogan', { fontFamily: 'Cabin', hover:true, textShadow:'#1063e4 1px 1px' });
Cufon.replace('h2, #menu a, h3, h4', { fontFamily: 'Cabin', hover:true });

