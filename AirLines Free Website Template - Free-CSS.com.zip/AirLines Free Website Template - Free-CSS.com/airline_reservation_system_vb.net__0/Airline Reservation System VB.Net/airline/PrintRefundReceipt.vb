﻿
Class PrintRefundReceipt

    Property strPnrNo As String

    Property strName As String

    Property dRefundAmt As String

    Sub ShowDialog()
        Throw New NotImplementedException
    End Sub

End Class
