package com.capgemini.web.ars.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.naming.NamingException;

import com.capgemini.web.ars.bean.Airport;
import com.capgemini.web.ars.bean.BookingInformation;
import com.capgemini.web.ars.bean.FlightInformation;
import com.capgemini.web.ars.util.DbUtil;

public class AirlineReservationDaoImpl implements IAirlineReservationDao
{
	Connection con = null;
	PreparedStatement pstm = null;
	
	@Override
	public void addAirport(Airport ap) 
	{
		try 
		{
			con = DbUtil.getConnection();
			
			String queryOne = 
			"INSERT INTO AIRPORT(AIRPORTNAME,ABBREVIATION,LOCATIONCITY,LOCATIONCOUNTRY,LOCATIONSTATE) VALUES(?,?,?,?,?)";
			
			pstm = con.prepareStatement(queryOne);
			pstm.setString(1, ap.getAirportName());
			pstm.setString(2, ap.getAbbreviation());
			pstm.setString(3, ap.getCity());
			pstm.setString(4, ap.getCountry());
			pstm.setString(5, ap.getState());
			
			pstm.executeUpdate();
		} 
		catch (NamingException | SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				con.close();
				pstm.close();
			} 
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Override
	public void addFlightInformation(FlightInformation flightInfo)

	{
		
		try 
		{
			con = DbUtil.getConnection();
			
			String queryTwo = "INSERT INTO FLIGHTINFORMATION"
+ "(FLIGHTNO,AIRLINE,DEP_ARP,ARR_ARP,DEP_DATE,ARR_DATE,DEP_TIME,ARR_TIME,FIRSTSEATS,FIRSTSEATFARE,BUSSSEATS,BUSSSEATSFARE) "
			+ "VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
			
			pstm = con.prepareStatement(queryTwo);
			
			pstm.setInt(1, flightInfo.getFlightno());
			pstm.setString(2, flightInfo.getAirline());
			pstm.setString(3, flightInfo.getDepArp().getAbbreviation());
			pstm.setString(4, flightInfo.getArrArp().getAbbreviation());
			pstm.setDate(5, flightInfo.getDep_date());
			pstm.setDate(6, flightInfo.getArr_date());
			pstm.setString(7, flightInfo.getDep_time());
			pstm.setString(8, flightInfo.getArr_time());
			pstm.setInt(9, flightInfo.getFirstSeats());
			pstm.setDouble(10, flightInfo.getFirstSeatFare());
			pstm.setInt(11, flightInfo.getBussSeats());
			pstm.setDouble(12, flightInfo.getBussSeatsFare());
			
			pstm.executeUpdate();
		} 
		catch (NamingException | SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				con.close();
				pstm.close();
			} 
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Override
	public int addBookingInformation(BookingInformation bookingEntry) 
	{
		int id = generatedId();
		int noOfSeats = bookingEntry.getNoOfAdult() + bookingEntry.getNoOfChildren();
		bookSeats(noOfSeats, bookingEntry.getClassType() , bookingEntry.getFlightNo());
		
		bookingEntry.setBookingId(id);
		try 
		{
			con = DbUtil.getConnection();
			
			String queryThree = "INSERT INTO BOOKINGINFORMATION"
+ "(BOOKINGID,CUSTOMEREMAIL,NO_OF_CHILDREN,NO_OF_ADULTS,CLASSTYPE,TOTALFARE,SEATNUMBERS,DEP_ARP,ARR_ARP,FLIGHTNO) "
			+ "VALUES(?,?,?,?,?,?,?,?,?,?)";
			
			pstm = con.prepareStatement(queryThree);
			
			pstm.setInt(1, id);
			pstm.setString(2, bookingEntry.getCustEmail());
			pstm.setInt(3, bookingEntry.getNoOfChildren());
			pstm.setInt(4, bookingEntry.getNoOfAdult());
			pstm.setString(5, bookingEntry.getClassType());
			pstm.setDouble(6, bookingEntry.getTotalFare());
			pstm.setString(7, bookingEntry.getSeatNumber());
			pstm.setString(8, bookingEntry.getSrcArp().getAbbreviation());
			pstm.setString(9, bookingEntry.getDestArp().getAbbreviation());
			pstm.setInt(10, bookingEntry.getFlightNo());
			
			pstm.executeUpdate();
		} 
		catch (NamingException | SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				con.close();
				pstm.close();
			} 
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return id;
	}

	@Override
	public ArrayList<FlightInformation> showOnDate(Date date)
	{
		
		
		ArrayList<FlightInformation> flightsDetails=null;
		try 
		{
			flightsDetails = new ArrayList<FlightInformation>();
			con = DbUtil.getConnection();

			pstm= con.prepareStatement("SELECT * FROM FLIGHTINFORMATION WHERE DEP_DATE = ?");
			pstm.setDate(1, date);
			ResultSet rs = pstm.executeQuery();
			
			FlightInformation flightInfo = null;
			
			Airport depArp=null;
			Airport arrArp=null;
			
			while(rs.next())
				{
				
					depArp = getAirport(rs.getString(3));
					arrArp = getAirport(rs.getString(4));
					
					flightInfo = new FlightInformation();
					
					flightInfo.setFlightno(rs.getInt(1));
					flightInfo.setAirline(rs.getString(2));
					flightInfo.setDepArp(depArp);
					flightInfo.setArrArp(arrArp);
					flightInfo.setDep_date(rs.getDate(5));
					flightInfo.setArr_date(rs.getDate(6));
					flightInfo.setDep_time(rs.getString(7));
					flightInfo.setArr_time(rs.getString(8));
					flightInfo.setFirstSeats(rs.getInt(9));
					flightInfo.setFirstSeatFare(rs.getInt(10));
					flightInfo.setBussSeats(rs.getInt(11));
					flightInfo.setBussSeatsFare(rs.getInt(12));
					
					flightsDetails.add(flightInfo);
				}
		}
		catch (NamingException | SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				con.close();
				pstm.close();
			} 
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	  
		return flightsDetails;
		
	}

	@Override
	public ArrayList<FlightInformation> viewFlightBtw(String depArp, String arrArp) 
	{
		ArrayList<FlightInformation> flightsDetails=null;
		try 
		{
			flightsDetails = new ArrayList<FlightInformation>();
			con = DbUtil.getConnection();

			pstm= con.prepareStatement("SELECT * FROM FLIGHTINFORMATION WHERE DEP_ARP = ? AND ARR_ARP = ?");
			pstm.setString(1, depArp);
			pstm.setString(1, arrArp);
			ResultSet rs = pstm.executeQuery();
			
			FlightInformation flightInfo = null;
			
			Airport depArpAbb=null;
			Airport arrArpAbb=null;
			
			while(rs.next())
				{
				
					depArpAbb = getAirport(rs.getString(3));
					arrArpAbb = getAirport(rs.getString(4));
					
					flightInfo = new FlightInformation();
					
					flightInfo.setFlightno(rs.getInt(1));
					flightInfo.setAirline(rs.getString(2));
					flightInfo.setDepArp(depArpAbb);
					flightInfo.setArrArp(arrArpAbb);
					flightInfo.setDep_date(rs.getDate(5));
					flightInfo.setArr_date(rs.getDate(6));
					flightInfo.setDep_time(rs.getString(7));
					flightInfo.setArr_time(rs.getString(8));
					flightInfo.setFirstSeats(rs.getInt(9));
					flightInfo.setFirstSeatFare(rs.getInt(10));
					flightInfo.setBussSeats(rs.getInt(11));
					flightInfo.setBussSeatsFare(rs.getInt(12));
					
					flightsDetails.add(flightInfo);
				}
		}
		catch (NamingException | SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				con.close();
				pstm.close();
			} 
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	  
		return flightsDetails;
	}

	@Override
	public ArrayList<BookingInformation> viewBookings(int flightNo) 
	{
		ArrayList<BookingInformation> bookingDetails=null;
		try 
		{
			bookingDetails = new ArrayList<BookingInformation>();
			con = DbUtil.getConnection();

			pstm= con.prepareStatement("SELECT * FROM BOOKINGINFORMATION WHERE FLIGHTNO = ?");
			pstm.setInt(1, flightNo);
			
			ResultSet rs = pstm.executeQuery();
			
			BookingInformation bookingInfo = null;
			
			Airport depArpAbb=null;
			Airport arrArpAbb=null;
			
			while(rs.next())
				{
				
					depArpAbb = getAirport(rs.getString(8));
					arrArpAbb = getAirport(rs.getString(9));
					
					bookingInfo = new BookingInformation();
					
					bookingInfo.setBookingId(rs.getInt(1));
					bookingInfo.setCustEmail(rs.getString(2));
					bookingInfo.setNoOfChildren(rs.getInt(3));
					bookingInfo.setNoOfAdult(rs.getInt(4));
					bookingInfo.setClassType(rs.getString(5));
					bookingInfo.setTotalFare(rs.getDouble(6));
					bookingInfo.setSeatNumber(rs.getString(7));
					bookingInfo.setSrcArp(depArpAbb);
					bookingInfo.setDestArp(arrArpAbb);
					bookingInfo.setFlightNo(rs.getInt(10));
					
					bookingDetails.add(bookingInfo);
					System.out.println(bookingDetails);
				}
		}
		catch (NamingException | SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				con.close();
				pstm.close();
			} 
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	  
		return bookingDetails;
		
	}

	@Override
	public FlightInformation viewFlightDetail(int flightNo) 
	{
		
		FlightInformation flightDetail=null;
		
		try 
		{
			flightDetail = new FlightInformation();
			con = DbUtil.getConnection();

			pstm= con.prepareStatement("SELECT * FROM FLIGHTINFORMATION WHERE FLIGHTNO = ?");
			pstm.setInt(1, flightNo);
			
			ResultSet rs = pstm.executeQuery();
			
			
			Airport depArp=null;
			Airport arrArp=null;
			
			while(rs.next())
				{					
					
					
					depArp = getAirport(rs.getString(3));
					arrArp = getAirport(rs.getString(4));
					
					
					flightDetail.setFlightno(rs.getInt(1));
					flightDetail.setAirline(rs.getString(2));
					flightDetail.setDepArp(depArp);
					flightDetail.setArrArp(arrArp);
					flightDetail.setDep_date(rs.getDate(5));
					flightDetail.setArr_date(rs.getDate(6));
					flightDetail.setDep_time(rs.getString(7));
					flightDetail.setArr_time(rs.getString(8));
					flightDetail.setFirstSeats(rs.getInt(9));
					flightDetail.setFirstSeatFare(rs.getInt(10));
					flightDetail.setBussSeats(rs.getInt(11));
					flightDetail.setBussSeatsFare(rs.getInt(12));
					
				}
		}
		catch (NamingException | SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				con.close();
				pstm.close();
			} 
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	  
		return flightDetail;
		
	}
	
	@Override
	public HashMap<String, Airport> getAirportList() 
	{
		 HashMap<String, Airport> airportList=new  HashMap<String, Airport>();

		try 
		{
			con = DbUtil.getConnection();
			
			String queryOne = 
			"SELECT AIRPORTNAME,ABBREVIATION,LOCATIONCITY,LOCATIONCOUNTRY,LOCATIONSTATE FROM AIRPORT";
			
			pstm = con.prepareStatement(queryOne);			
			ResultSet rs = pstm.executeQuery();
			
			Airport arp;
			
			while(rs.next())
			{
				arp = new Airport();
				
				arp.setAirportName(rs.getString(1));
				arp.setAbbreviation(rs.getString(2));
				arp.setCity(rs.getString(3));
				arp.setCountry(rs.getString(4));
				arp.setState(rs.getString(5));
				
				airportList.put(arp.getAbbreviation(), arp);
			}
		} 
		catch (NamingException | SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				con.close();
				pstm.close();
			} 
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return airportList;
	}
	
	@Override
	public ArrayList<FlightInformation> viewFlightOn(String depArp,
			String arrArp, Date date) 
	{
		ArrayList<FlightInformation> flightsDetails=null;
		try 
		{
			flightsDetails = new ArrayList<FlightInformation>();
			con = DbUtil.getConnection();

			pstm= con.prepareStatement("SELECT * FROM FLIGHTINFORMATION WHERE DEP_ARP = ? AND ARR_ARP = ? AND DEP_DATE = ?");
			pstm.setString(1, depArp);
			pstm.setString(2, arrArp);
			pstm.setDate(3, date);
			ResultSet rs = pstm.executeQuery();
			
			FlightInformation flightInfo = null;
			
			Airport depArpAbb=null;
			Airport arrArpAbb=null;
			
			while(rs.next())
				{
				
					depArpAbb = getAirport(rs.getString(3));
					arrArpAbb = getAirport(rs.getString(4));
					
					flightInfo = new FlightInformation();
					
					flightInfo.setFlightno(rs.getInt(1));
					flightInfo.setAirline(rs.getString(2));
					flightInfo.setDepArp(depArpAbb);
					flightInfo.setArrArp(arrArpAbb);
					flightInfo.setDep_date(rs.getDate(5));
					flightInfo.setArr_date(rs.getDate(6));
					flightInfo.setDep_time(rs.getString(7));
					flightInfo.setArr_time(rs.getString(8));
					flightInfo.setFirstSeats(rs.getInt(9));
					flightInfo.setFirstSeatFare(rs.getInt(10));
					flightInfo.setBussSeats(rs.getInt(11));
					flightInfo.setBussSeatsFare(rs.getInt(12));
					
					flightsDetails.add(flightInfo);
				}
		}
		catch (NamingException | SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				con.close();
				pstm.close();
			} 
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	  
		return flightsDetails;
	}

	@Override
	public ArrayList<FlightInformation> showAllFlights()
	{

		ArrayList<FlightInformation> flightsDetails=null;
		try 
		{
			flightsDetails = new ArrayList<FlightInformation>();
			con = DbUtil.getConnection();

			pstm= con.prepareStatement("SELECT * FROM FLIGHTINFORMATION");
			
			ResultSet rs = pstm.executeQuery();
			
			FlightInformation flightInfo = null;
			
			Airport depArpAbb=null;
			Airport arrArpAbb=null;
			
			while(rs.next())
				{
				
					depArpAbb = getAirport(rs.getString(3));
					arrArpAbb = getAirport(rs.getString(4));
					
					flightInfo = new FlightInformation();
					
					flightInfo.setFlightno(rs.getInt(1));
					flightInfo.setAirline(rs.getString(2));
					flightInfo.setDepArp(depArpAbb);
					flightInfo.setArrArp(arrArpAbb);
					flightInfo.setDep_date(rs.getDate(5));
					flightInfo.setArr_date(rs.getDate(6));
					flightInfo.setDep_time(rs.getString(7));
					flightInfo.setArr_time(rs.getString(8));
					flightInfo.setFirstSeats(rs.getInt(9));
					flightInfo.setFirstSeatFare(rs.getInt(10));
					flightInfo.setBussSeats(rs.getInt(11));
					flightInfo.setBussSeatsFare(rs.getInt(12));
					
					flightsDetails.add(flightInfo);
				}
		}
		catch (NamingException | SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				con.close();
				pstm.close();
			} 
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	  
		return flightsDetails;
	}

	
	@Override
	public void updateFlightInformation(FlightInformation updateflight) 
	{
		try
		{
		con =DbUtil.getConnection();
		String queryEleven = "UPDATE FLIGHTINFORMATION SET AIRLINE=?,DEP_ARP=?,ARR_ARP=?,DEP_DATE=?,"
     + "ARR_DATE=?,DEP_TIME=?,ARR_TIME=?,FIRSTSEATS=?,FIRSTSEATFARE=?,BUSSSEATS=?,BUSSSEATSFARE=? WHERE FLIGHTNO=?";
			
			pstm = con.prepareStatement(queryEleven);
			
			
			pstm.setString(1, updateflight.getAirline());
			pstm.setString(2, updateflight.getDepArp().getAbbreviation());
			pstm.setString(3, updateflight.getArrArp().getAbbreviation());
			pstm.setDate(4, updateflight.getDep_date());
			pstm.setDate(5, updateflight.getArr_date());
			pstm.setString(6, updateflight.getDep_time());
			pstm.setString(7, updateflight.getArr_time());
			pstm.setInt(8, updateflight.getFirstSeats());
			pstm.setDouble(9, updateflight.getFirstSeatFare());
			pstm.setInt(10, updateflight.getBussSeats());
			pstm.setDouble(11, updateflight.getBussSeatsFare());
			
			
			pstm.setInt(12, updateflight.getFlightno());
			
			pstm.executeUpdate();
			
		}
		catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				con.close();
				pstm.close();
			} 
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}
	}

	@Override
	public void removeFlightInformation(int flightNo)
	{
		try
		{
			con = DbUtil.getConnection();
			String querrytweleve = "DELETE FROM FlightInformation WHERE FLIGHTNO = ?";
			pstm = con.prepareStatement(querrytweleve);
			pstm.setInt(1, flightNo);
			pstm.executeUpdate();
			
		} 
		catch (NamingException | SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}	
	
	
	
	
	
	    //***********************************************************************************************************
		//methods only for dao
		//***********************************************************************************************************
		
	private int generatedId()

	{
		int id = 0;
		try 
		{
			con = DbUtil.getConnection();
			pstm= con.prepareStatement("SELECT BOOKING_ID_SEQ.NEXTVAL FROM DUAL");
			
			ResultSet rs = pstm.executeQuery();
			
			if(rs.next())
				{
					id = rs.getInt(1);
				}
		}
		catch (NamingException | SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				con.close();
				pstm.close();
			} 
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	  return id;
	}

	
	private Airport getAirport(String abv)
	{
		Airport airport = null;
		try 
		{
			con = DbUtil.getConnection();
			
			String queryOne = 
			"SELECT * FROM AIRPORT WHERE ABBREVIATION=?";
			
			pstm = con.prepareStatement(queryOne);
			pstm.setString(1, abv);
			
			ResultSet rs = pstm.executeQuery();
			
			if(rs.next())
			{
				airport = new Airport();
				airport.setAbbreviation(abv);
				airport.setAirportName(rs.getString(1));
				airport.setCity(rs.getString(3));
				airport.setCountry(rs.getString(4));
				airport.setCountry(rs.getString(5));
			}
			
	
		} 
		catch (NamingException | SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				con.close();
				pstm.close();
			} 
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
		return airport;
	}

	
	private void bookSeats(int seats , String classType , int flightId)
	{
		try 
		{
			con = DbUtil.getConnection();
			String query = null;
			
			
			if(classType.equals("firstclass"))
			{
				query = "UPDATE flightinformation SET firstseats = firstseats - ? where flightno=?";
				
				PreparedStatement pstm = con.prepareStatement(query);
				pstm.setInt(1, seats);
				pstm.setInt(2, flightId);
				pstm.executeUpdate();
			}
			
			else if(classType.equals("businessclass"))
			{
				query = "UPDATE flightinformation SET bussseats = bussseats - ? where flightno=?";
				
				PreparedStatement pstm = con.prepareStatement(query);
				pstm.setInt(1, seats);
				pstm.setInt(2, flightId);
				pstm.executeUpdate();
			}
			
		} 
		catch (NamingException | SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				con.close();
			} 
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	private void releaseSeats(int seats , String classType , int flightId)
	{
		try 
		{
			con = DbUtil.getConnection();
			String query = null;
			
			
			if(classType.equals("firstclass"))
			{
				query = "UPDATE flightinformation SET firstseats = firstseats + ? where flightno=?";
				
				PreparedStatement pstm = con.prepareStatement(query);
				pstm.setInt(1, seats);
				pstm.setInt(1, flightId);
				pstm.executeUpdate();
			}
			
			else if(classType.equals("businessclass"))
			{
				query = "UPDATE flightinformation SET bussseats = bussseats + ? where flightno=?";
				
				PreparedStatement pstm = con.prepareStatement(query);
				pstm.setInt(1, seats);
				pstm.setInt(1, flightId);
				pstm.executeUpdate();
			}
			
		} 
		catch (NamingException | SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				con.close();
			} 
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}


	
}
