package com.capgemini.web.ars.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import javax.servlet.http.HttpSession;

import org.jboss.security.ISecurityManagement;

import com.capgemini.web.ars.bean.Airport;
import com.capgemini.web.ars.bean.BookingInformation;
import com.capgemini.web.ars.bean.FlightInformation;
import com.capgemini.web.ars.service.AirlineReservationServiceImpl;
import com.capgemini.web.ars.service.IAirlineReservationService;
import com.capgemini.web.ars.util.DbUtil;


@WebServlet("*.do")
public class Controller extends HttpServlet {

	Connection conn = null;
	PreparedStatement pstm = null; 
	
	//getting airports data for reusability
	HashMap<String, Airport> airportData =  new HashMap<>(); 
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String action = request.getServletPath();
		
		IAirlineReservationService servObj = new AirlineReservationServiceImpl();
		
		 airportData= servObj.getAirportList();
		switch(action){
		
		case "/login.do":
			
			RequestDispatcher view= request.getRequestDispatcher("login.jsp");
			view.forward(request, response);
			
		break;
		
		case "/enter.do":
			String uname=request.getParameter("uname");
			String pass=request.getParameter("pass");
	
			try
			{
					conn = DbUtil.getConnection();
					PreparedStatement pstm=conn.prepareStatement("Select role from  users"
							+ " where username = ? and password = ? ");
					pstm.setString(1,uname);
					pstm.setString(2, pass);
					ResultSet res = pstm.executeQuery();
					
					 String roles=null;
					 
					 if(res.next())
					 {
						  roles=res.getString("role");
					 } 
					
					  if(roles==null || roles.equals(""))
					    {
					    	  
							  response.sendRedirect("login.jsp");	
					    }
				 
					  else if(roles.equals("admin")) 
						    { 				       
						  		request.setAttribute("role", roles);
						   		RequestDispatcher rd = request.getRequestDispatcher("Admin.jsp");
						   		rd.forward(request, response);
						    } 
					  else if(roles.equals("executive")) 
						    { 
						    	System.out.println(roles); 
						    	request.setAttribute("type", roles);
						    	RequestDispatcher rd = request.getRequestDispatcher("Excecutive.jsp");
						    	rd.forward(request, response);
						    } 
					  
			}
			
				 
			 catch (NamingException | SQLException e)
			{
				e.printStackTrace();
			}
			
			
			break;
			
			case "/processAddFlight.do":
				//converting keyset to arraylist
			        Set<String> arpAbbSet = airportData.keySet();
			        ArrayList<String> airportList = new ArrayList(arpAbbSet);
			  
			   		HttpSession session = request.getSession();
			   		session.setAttribute("arpList",airportList);
			    
			   		System.out.println(airportList);
			   		
			   		RequestDispatcher rd = request.getRequestDispatcher("addNewFlight.jsp");
			   		rd.forward(request, response);
			break;
			
            case "/addFlight.do":
			
            	 String flightno = request.getParameter("flightId");
            	 String airline = request.getParameter("airline");
            	 String depArpAbb = request.getParameter("depArp");
            	 String arrArpAbb = request.getParameter("arrArp");
            	 
            	 String dep_date = request.getParameter("depDate");
            	 String arr_date = request.getParameter("arrDate");
            	 
            	 String dep_time = request.getParameter("depTime");
            	 String arr_time = request.getParameter("arrTime");
            	 String FirstSeats = request.getParameter("FirstSeats");
            	 String FirstSeatFare = request.getParameter("FirstSeatFare");
            	 String BussSeats = request.getParameter("BussSeats");
            	 String BussSeatsFare= request.getParameter("BussSeatsFare");
            	
            	 
            	 //getting Airport data from abbreviation
            	 Airport depArp = airportData.get(depArpAbb);
            	 Airport arrArp = airportData.get(arrArpAbb);
            	 
            	 
            	 //converting string date to sql date
            	 Date depDatesql = null;
            	 Date arrDatesql = null;
            	 SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            	 
            	 try 
            	 	{
            		 	java.util.Date depDateUtil = format.parse(dep_date);
            		 	depDatesql = new java.sql.Date(depDateUtil.getTime());
                 
            		 	java.util.Date arrDateUtil = format.parse(arr_date);
            		 	arrDatesql = new java.sql.Date(arrDateUtil.getTime());
            	 	} 
            	 catch (ParseException e) 
            	 {
            		 e.printStackTrace();
            	 }
                 
            	 FlightInformation fi = new FlightInformation();
            	 
            	 fi.setFlightno(Integer.parseInt(flightno));
            	 fi.setAirline(airline);
            	 fi.setDepArp(depArp);
            	 fi.setArrArp(arrArp);
            	 
            	 fi.setDep_date(depDatesql);
            	 fi.setArr_date(arrDatesql);
            	 
            	 fi.setDep_time(dep_time);
            	 fi.setArr_time(arr_time);
            	 fi.setFirstSeats(Integer.parseInt(FirstSeats));
            	 fi.setFirstSeatFare(Double.parseDouble(FirstSeatFare));
            	 fi.setBussSeats(Integer.parseInt(BussSeats));
            	 fi.setBussSeatsFare(Double.parseDouble(BussSeatsFare));
                 
            	 servObj.addFlightInformation(fi);
            	 
            	 response.sendRedirect("showAllFlights.do");
	     	break;
	     	

    		case "/showAllFlights.do":
    			
    			ArrayList<FlightInformation> allFlightInfo = servObj.showAllFlights();
    			
    			request.setAttribute("flightData", allFlightInfo);
    			rd = request.getRequestDispatcher("showFlights.jsp");
		   		rd.forward(request, response);
    			
    		break;
    		
    		case "/bookFlight.do":
    			
    			     arpAbbSet = airportData.keySet();
			        airportList = new ArrayList(arpAbbSet);
			 
			   		 session = request.getSession();
			   		 
			   		session.setAttribute("arpList",airportList);
    			
    			      RequestDispatcher dis = request.getRequestDispatcher("bookFlight.jsp");
    			      dis.forward(request, response);
    			
    		break;
    		case "/processBookingDetails.do":
    			 session = request.getSession(false);
    			 
    			 
    			 depArpAbb = request.getParameter("depArp");
    			 session.setAttribute("depArp", depArpAbb);
    			 
    		     arrArpAbb = request.getParameter("arrArp");
    		     session.setAttribute("arrArp", arrArpAbb);
    		     
    		     arr_date = request.getParameter("arrDate");
    		     dep_date = request.getParameter("depDate");
    		     
    		     session.setAttribute("arrDate", arr_date);
    		     session.setAttribute("depDate", dep_date);
    		     
    		     String trip = request.getParameter("flightWay");
    		     session.setAttribute("trip", trip);
    		     
    		     int children =  Integer.parseInt(request.getParameter("noOfChildren"));
    		     
    		  
    		     int adults =  Integer.parseInt(request.getParameter("noOfAdults"));
    		   
    		     
    		     String classType = request.getParameter("classType");
    		     
    		     session.setAttribute("children", children);
    		     session.setAttribute("adult", adults);
    		     session.setAttribute("class", classType);
    		     
    		     //converting string date to sql date
            	 depDatesql = null;
            	 arrDatesql = null;
            	 format = new SimpleDateFormat("yyyy-MM-dd");
            	 
            	 try 
            	 	{
            		 	java.util.Date depDateUtil = format.parse(dep_date);
            		 	depDatesql = new java.sql.Date(depDateUtil.getTime());
                 
            		 	java.util.Date arrDateUtil = format.parse(arr_date);
            		 	arrDatesql = new java.sql.Date(arrDateUtil.getTime());
            	 	} 
            	 catch (ParseException e) 
            	 	{
            		 	e.printStackTrace();
            	 	}
    		
    		     ArrayList<FlightInformation> upFlights = servObj.viewFlightOn(depArpAbb, arrArpAbb,  depDatesql);
    		     ArrayList<FlightInformation> downFlights = null;
    		     if(trip.equals("roundTrip"))
    		     {
    		         downFlights = servObj.viewFlightOn(arrArpAbb , depArpAbb , arrDatesql);
    		     }
    		    
    		      
    		     session.setAttribute("upflights", upFlights);
    		     session.setAttribute("downflights", downFlights);
    		     session.setAttribute("children", children);
    		     session.setAttribute("adults", adults);
    		     session.setAttribute("classType", classType);
    		     
    		     dis = request.getRequestDispatcher("viewAvailableFlight.jsp");
			     dis.forward(request, response);
    		     
    		break;
    		
    		case "/reserveFlight.do":
    			
    			  String email = request.getParameter("email");
    			 // System.out.println("email" + email);
    			  children = Integer.parseInt(request.getParameter("children"));
    			  adults =  Integer.parseInt(request.getParameter("adults"));
    			  //System.out.println("child" + children + "adult" +adults);
    			  
    			  classType = request.getParameter("class");
    			  //System.out.println("class" + classType);
    			  
    			  depArpAbb =  request.getParameter("depArp");
    			  arrArpAbb =  request.getParameter("arrArp");
    			  
    			  //System.out.println("dep arp" + depArpAbb + "arr arp" + arrArpAbb);
    			 // System.out.println("upFlight number " + request.getParameter("upFlight"));
    			 // System.out.println("downFlight number " + request.getParameter("downFlight"));
    			  
    			  
    			  Integer upFlightNo =  Integer.parseInt(request.getParameter("upFlight"));
    			  
    			  BookingInformation bi = new BookingInformation();
    			  bi.setClassType(classType);
    			  bi.setCustEmail(email);
    			  bi.setNoOfChildren(children);
    			  bi.setNoOfAdult(adults);
    			  bi.setSrcArp(airportData.get(depArpAbb));
    			  bi.setDestArp(airportData.get(arrArpAbb));
    			  bi.setFlightNo(upFlightNo);
    			  
    			  double upTotalFare = 0;
    			  
    		
    			  
    			  FlightInformation upFlight = servObj.viewFlightDetail(upFlightNo);
    			  
    			 
    			  
    			  if(classType.equals("firstclass"))
    			  {
    				  upTotalFare = (children+adults) * upFlight.getFirstSeatFare();
    			  }
    				  
    			  else if(classType.equals("businessclass"))
    			  {
    				  upTotalFare = (children+adults) * upFlight.getBussSeatsFare();
    			  }
    			  
    			  
    			  bi.setTotalFare( upTotalFare);
    			  
    			  
    			  int upBookingId = servObj.addBookingInformation(bi);
    			  
    			 String downStatus = request.getParameter("downFlight");
    			  
    			 int downBookingId = 0;
    			 
    			 if(downStatus != null)
    			  {
    				  System.out.println("aa gaya");
    				  Integer downFlightNo =  Integer.parseInt(request.getParameter("downFlight"));
    				  bi.setSrcArp(airportData.get(arrArpAbb));
        			  bi.setDestArp(airportData.get(depArpAbb));
        			  bi.setFlightNo(downFlightNo);
    				  
        			  FlightInformation downFlight = servObj.viewFlightDetail(downFlightNo);
        			  
        			  double downTotalFare = 0;
        			  
    				  if(classType.equals("firstclass"))
        			  {
    					  downTotalFare = (children+adults) * downFlight.getFirstSeatFare();
        			  }
        				  
        			  else if(classType.equals("businessclass"))
        			  {
        				  downTotalFare = (children+adults) * downFlight.getBussSeatsFare();
        			  }
        			  
    				  System.out.println("down total fare" + downTotalFare);
        			  bi.setTotalFare(downTotalFare);
        			  
        			  
        			  downBookingId = servObj.addBookingInformation(bi);
        			  
        			  System.out.println("down booking Id= " +downBookingId);
    			  }
    			 
    			  System.out.println("up booking Id= " +upBookingId);
    			 
    			  request.setAttribute("upBookingID",upBookingId);
    			  request.setAttribute("downBookingID",downBookingId);
    			  RequestDispatcher view3 = request.getRequestDispatcher("Sucess.jsp");
    			  view3.forward(request, response);
    			  
    			  
    		break;
    		
    		case "/edit.do":
    			String flightNo = request.getParameter("flno");
    			String error;
    			if(flightNo!=null)
    			{
    				int flno = Integer.parseInt(flightNo);
    				FlightInformation flightInfo = servObj.viewFlightDetail(flno);
    				request.setAttribute("flinfo", flightInfo);
    				

 				    arpAbbSet = airportData.keySet();
				    airportList = new ArrayList(arpAbbSet);
 				
				    request.setAttribute("arpList",airportList);
    				RequestDispatcher view1 = request.getRequestDispatcher("edit.jsp");
    				view1.forward(request, response);
    			}
    			else
    			{
    				error = "Cannot search any flight number ";
    			}
    			
    		break;
    		
    		case "/update.do":
    			
    			System.out.println("inside update.do");
    			
    			 String flightno1 = request.getParameter("flightId");
            	 String airline1 = request.getParameter("airline");
            	 String depArpAbb1 = request.getParameter("depArp");
            	 String arrArpAbb1 = request.getParameter("arrArp");
            	 String dep_date1 = request.getParameter("depDate");
            	 String arr_date1 = request.getParameter("arrDate");
                   
            
            	 
            	 String dep_time1 = request.getParameter("depTime");
            	 String arr_time1 = request.getParameter("arrTime");
            	 String FirstSeats1 = request.getParameter("FirstSeats");
            	 String FirstSeatFare1 = request.getParameter("FirstSeatFare");
            	 String BussSeats1 = request.getParameter("BussSeats");
            	 String BussSeatsFare1= request.getParameter("BussSeatsFare");
            	
            	 
            	 //getting Airport data from abbreviation
            	 Airport depArp1 = airportData.get(depArpAbb1);
            	 Airport arrArp1 = airportData.get(arrArpAbb1);
            	 
            	 //converting string date to sql date
           	 Date depDatesql1 = null;
           	 Date arrDatesql1 = null;
            	 
       
    
           	 
            	 SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
            	 
            	 
            	 try 
            	 	{
            		 	java.util.Date depDateUtil = format1.parse(dep_date1);
            		 	
            		 	depDatesql1 = new java.sql.Date(depDateUtil.getTime());
                 
            		
            		 	
            		 	java.util.Date arrDateUtil = format1.parse(arr_date1);
            		 	arrDatesql1 = new java.sql.Date(depDateUtil.getTime());
            		 	 	
            	/*	 	 System.out.println("**********************utility*********************");
           				System.out.println(depDateUtil);
           				System.out.println(arrDateUtil);
           				System.out.println("*******************************************");
           				
           			 System.out.println("******************sql*************************");
       				System.out.println(depDatesql1);
       				System.out.println(arrDatesql1);
       				System.out.println("*******************************************");
            	*/		
            	 	} 
            	            	 
            	 catch (ParseException e) 
            	 {
            		 e.printStackTrace();
            	 }
  				
            	 FlightInformation fi1 = new FlightInformation();
            	 
            	 fi1.setFlightno(Integer.parseInt(flightno1));
            	 fi1.setAirline(airline1);
            	 fi1.setDepArp(depArp1);
            	 fi1.setArrArp(arrArp1);
            	 fi1.setDep_date(depDatesql1);
            	 fi1.setArr_date(arrDatesql1);
            	 fi1.setDep_time(dep_time1);
            	 fi1.setArr_time(arr_time1);
            	 fi1.setFirstSeats(Integer.parseInt(FirstSeats1));
            	 fi1.setFirstSeatFare(Double.parseDouble(FirstSeatFare1));
            	 fi1.setBussSeats(Integer.parseInt(BussSeats1));
            	 fi1.setBussSeatsFare(Double.parseDouble(BussSeatsFare1));
                 
            	 servObj.updateFlightInformation(fi1);;
            	 RequestDispatcher view1 = request.getRequestDispatcher("showAllFlights.do");
     			view1.forward(request, response);
     			
    		case "/remove.do":
    			
    			System.out.println("afsdssad");
    			 flightNo = request.getParameter("flno");
    			 
    			 String error1;
    			 
    				if(flightNo!=null)
        			{
        				int flno = Integer.parseInt(flightNo);
        				
        				servObj.removeFlightInformation(flno);
        				
        				System.out.println(flno);
        				
        				RequestDispatcher view2 = request.getRequestDispatcher("showAllFlights.do");
        				view2.forward(request, response);
        			}
        			else
        			{
        				error = "Cannot remove any flight number";
        			}
    			
    			break;
    		
    		case "/viewAllFlights.do":
    			
    			ArrayList<FlightInformation> alldata = servObj.showAllFlights();
    			request.setAttribute("flightinfo", alldata);
    			RequestDispatcher view2 = request.getRequestDispatcher("showFlightsData.jsp");
    			view2.forward(request, response);
    		break;
    		
    		case "/bookinginformation.do":
    			String flightNum = request.getParameter("flno");
    			String error2;
    			if(flightNum != null){
    				
    				int flno = Integer.parseInt(flightNum);
    				System.out.println(flno);
    				ArrayList<BookingInformation> bookinfo = servObj.viewBookings(flno);
    				
    				System.out.println(bookinfo);
    				
    				request.setAttribute("booking",bookinfo );
    				RequestDispatcher view4 = request.getRequestDispatcher("bookinfo.jsp");
    				view4.forward(request, response);
    			}
    			else{
    				
    				error2 = "Cannot find any bokings with this flightid";
    			}
    			break;
    			default:
    			break;
		}
	}
	
}
